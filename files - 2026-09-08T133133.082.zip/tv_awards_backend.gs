/**
 * CADET TV PERSONALITY AWARDS 2026 — REGISTRATION BACKEND
 * ─────────────────────────────────────────────────────────
 * HOW TO DEPLOY:
 * 1. Open (or create) the Google Sheet you want registrations saved to.
 * 2. Go to Extensions → Apps Script.
 * 3. Delete any starter code and paste this whole file in.
 * 4. Set SHARED_SECRET below to a random string, and put the SAME string
 *    into APP_SECRET in tv_awards_register.html.
 * 5. Set ORGANIZER_EMAIL below to the inbox that should get notified of
 *    every new registration.
 * 6. Click Deploy → New deployment → type: "Web app".
 *    - Execute as: Me
 *    - Who has access: Anyone
 * 7. Copy the resulting Web App URL and paste it into
 *    APPS_SCRIPT_URL in tv_awards_register.html.
 *
 * The first submission will auto-create a "Registrations" sheet tab
 * with headers if one doesn't already exist, and a Drive folder for
 * the uploaded photos.
 *
 * ── SECURITY NOTES (read this) ──
 * This is a client-side web page calling a public Apps Script URL, so
 * there is no way to make it 100% bot-proof — anyone determined enough
 * can view the page source and find both the URL and the shared secret.
 * What's below raises the bar significantly against casual spam/scraping
 * (the vast majority of real-world abuse) but is not equivalent to a
 * proper authenticated backend. If this becomes a high-value target,
 * consider adding Google reCAPTCHA v3 verification on top of this.
 */

var SHEET_NAME = 'Registrations';
var PHOTO_FOLDER_NAME = 'CTVA 2026 Student Photos';

// Cadet Media Ghana's own inbox — gets notified of every new registration.
var ORGANIZER_EMAIL = 'PASTE_ORGANIZER_EMAIL_HERE@example.com';

// Must match APP_SECRET in tv_awards_register.html exactly.
// Change this to your own random string before deploying.
var SHARED_SECRET = 'ctva2026-secure-x7k9m';

// Simple global throttle: max submissions allowed per rolling minute,
// across all users. Cheap protection against a burst flood from a bot.
var MAX_SUBMISSIONS_PER_MINUTE = 15;

// Hard cap on decoded photo size (bytes) — guards Drive storage from abuse
// even if someone bypasses the client-side compression.
var MAX_PHOTO_BYTES = 4 * 1024 * 1024; // 4MB

function doGet(e) {
  return jsonOut({ status: 'error', message: 'Use POST for registerStudent' });
}

function doPost(e) {
  var p;
  try {
    p = JSON.parse(e.postData.contents);
  } catch (err) {
    return jsonOut({ status: 'error', message: 'Invalid request body' });
  }

  // ── 1. Shared secret check ──
  if (!SHARED_SECRET || SHARED_SECRET.indexOf('CHANGE_ME') === 0) {
    return jsonOut({ status: 'error', message: 'Server not configured: set SHARED_SECRET' });
  }
  if (p.secret !== SHARED_SECRET) {
    return jsonOut({ status: 'error', message: 'Unauthorized' });
  }

  // ── 2. Honeypot check ──
  // A hidden field real users never see or fill. If it has a value,
  // it was almost certainly filled in by an automated bot.
  if (p.website) {
    return jsonOut({ status: 'ok', ref: p.ref || '', note: 'silently ignored' });
  }

  // ── 3. Global rate limit ──
  if (isRateLimited()) {
    return jsonOut({ status: 'error', message: 'Too many submissions right now. Please try again in a minute.' });
  }

  if (p.action === 'registerStudent') {
    return registerStudent(p);
  }

  return jsonOut({ status: 'error', message: 'Unknown action' });
}

function isRateLimited() {
  var cache = CacheService.getScriptCache();
  var key = 'submits_' + Math.floor(Date.now() / 60000); // bucket per minute
  var count = Number(cache.get(key) || 0) + 1;
  cache.put(key, String(count), 90); // expire after 90s
  return count > MAX_SUBMISSIONS_PER_MINUTE;
}

function registerStudent(p) {
  // ── 4. Server-side field validation ──
  // Never trust the client alone — validate again here.
  var errors = validateRegistration(p);
  if (errors.length) {
    return jsonOut({ status: 'error', message: errors[0] });
  }

  var sheet = getOrCreateSheet();
  var data = sheet.getDataRange().getValues();

  // Column indices (0-based), matching the row layout below:
  // 0 Ref, 1 Name, 2 DOB, 3 Gender, 4 Level, 5 School, 6 Region, 7 Grade,
  // 8 Category, 9 ParentName, 10 ParentPhone, 11 ParentEmail, 12 Consent,
  // 13 PhotoURL, 14 SubmittedClient, 15 SubmittedServer
  var COL_REF = 0, COL_NAME = 1, COL_SCHOOL = 5, COL_CATEGORY = 8;

  // Avoid duplicate double-submits with the same reference code
  for (var i = 1; i < data.length; i++) {
    if (data[i][COL_REF] === p.ref) {
      return jsonOut({ status: 'ok', ref: p.ref, note: 'duplicate ignored' });
    }
  }

  // ── 5. One student per nominee category, per school ──
  // Two students from the SAME school cannot compete in the same category
  // (e.g. two "Best Local News Anchor" entries from one school). Different
  // schools may each have their own nominee in the same category — that's
  // expected, since every school can field its own 15 nominees.
  var thisSchool = text_(p.school).toLowerCase();
  var thisCategory = text_(p.category).toLowerCase();
  for (var j = 1; j < data.length; j++) {
    var rowSchool = String(data[j][COL_SCHOOL] || '').toLowerCase().trim();
    var rowCategory = String(data[j][COL_CATEGORY] || '').toLowerCase().trim();
    if (rowSchool === thisSchool && rowCategory === thisCategory) {
      var takenBy = data[j][COL_NAME] || 'another student';
      return jsonOut({
        status: 'error',
        message: '"' + p.category + '" has already been claimed at ' + p.school +
          ' by ' + takenBy + '. Please choose a different nominee category.'
      });
    }
  }

  var photoUrl = '';
  if (p.photoData) {
    try {
      photoUrl = savePhotoToDrive(p.photoData, p.ref, p.studentName);
    } catch (err) {
      // Never fail the whole registration just because the photo couldn't
      // be saved — log it and keep the photo column blank instead.
      photoUrl = 'ERROR: ' + err.message;
    }
  }

  sheet.appendRow([
    p.ref || '',
    sanitize(p.studentName),
    p.dob || '',
    p.gender || '',
    p.level || '',
    sanitize(p.school),
    p.region || '',
    sanitize(p.studentClass),
    p.category || '',
    sanitize(p.parentName),
    sanitize(p.parentPhone),
    sanitize(p.parentEmail),
    p.consent || '',
    photoUrl,
    p.date || new Date().toISOString(),
    new Date() // server timestamp
  ]);

  if (text_(p.parentEmail)) {
    try {
      sendConfirmationEmail(p, photoUrl);
    } catch (err) {
      // Never fail the registration just because the email couldn't send
      // (e.g. daily Gmail quota hit) — the row is already saved either way.
      Logger.log('Parent email send failed for ' + p.ref + ': ' + err.message);
    }
  }

  try {
    sendOrganizerNotification(p, photoUrl);
  } catch (err) {
    Logger.log('Organizer notification failed for ' + p.ref + ': ' + err.message);
  }

  return jsonOut({ status: 'ok', ref: p.ref, photoUrl: photoUrl });
}

function text_(v) { return (typeof v === 'string') ? v.trim() : ''; }

// Sends a confirmation email to the parent/guardian using Apps Script's
// built-in mail service — sent from the Google account this script is
// deployed under. Free Gmail accounts have a ~100 emails/day quota;
// Google Workspace accounts get a much higher limit.
function sendConfirmationEmail(p, photoUrl) {
  var subject = 'Registration Confirmed — Cadet TV Personality Awards 2026';
  var body =
    'Dear ' + p.parentName + ',\n\n' +
    'Thank you for registering ' + p.studentName + ' for the Cadet TV Personality Awards 2026.\n\n' +
    'Registration details:\n' +
    '  Reference: ' + p.ref + '\n' +
    '  Student: ' + p.studentName + '\n' +
    '  Level: ' + p.level + '\n' +
    '  School: ' + p.school + '\n' +
    '  Region: ' + p.region + '\n' +
    '  Class: ' + p.studentClass + '\n' +
    '  Nominee Category: ' + p.category + '\n\n' +
    'Please keep this reference number safe — you may need it for follow-up.\n' +
    'The GH₵400 participation fee will be collected by the school, not online.\n\n' +
    'Thank you for supporting your child/ward\'s participation.\n\n' +
    'Cadet Media Ghana\n' +
    'Cadet TV Personality Awards 2026';

  var htmlBody =
    '<div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;">' +
    '<h2 style="color:#B8860B;">Registration Confirmed 🎬</h2>' +
    '<p>Dear ' + p.parentName + ',</p>' +
    '<p>Thank you for registering <strong>' + p.studentName + '</strong> for the ' +
    '<strong>Cadet TV Personality Awards 2026</strong>.</p>' +
    '<table style="width:100%;border-collapse:collapse;font-size:14px;">' +
    '<tr><td style="padding:4px 0;color:#666;">Reference</td><td style="padding:4px 0;"><strong>' + p.ref + '</strong></td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Gender</td><td style="padding:4px 0;">' + p.gender + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Level</td><td style="padding:4px 0;">' + p.level + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">School</td><td style="padding:4px 0;">' + p.school + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Region</td><td style="padding:4px 0;">' + p.region + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Grade</td><td style="padding:4px 0;">' + p.studentClass + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Nominee Category</td><td style="padding:4px 0;">' + p.category + '</td></tr>' +
    '</table>' +
    (photoUrl && photoUrl.indexOf('ERROR') !== 0 ? '<p><img src="' + photoUrl + '" width="90" style="border-radius:50%;"></p>' : '') +
    '<p style="font-size:13px;color:#666;">Please keep this reference number safe. The GH₵400 participation fee ' +
    'will be collected by the school, not online.</p>' +
    '<p style="font-size:13px;color:#999;">— Cadet Media Ghana</p>' +
    '</div>';

  MailApp.sendEmail({
    to: p.parentEmail,
    subject: subject,
    body: body,
    htmlBody: htmlBody,
    name: 'Cadet Media Ghana'
  });
}

// Notifies the organizer (Cadet Media Ghana) of every new registration,
// so they don't have to keep checking the sheet manually.
function sendOrganizerNotification(p, photoUrl) {
  if (!ORGANIZER_EMAIL || ORGANIZER_EMAIL.indexOf('PASTE_ORGANIZER') === 0) {
    Logger.log('ORGANIZER_EMAIL not set — skipping organizer notification.');
    return;
  }

  var subject = 'New Registration: ' + p.studentName + ' (' + p.ref + ')';
  var body =
    'A new student has registered for the Cadet TV Personality Awards 2026.\n\n' +
    '  Reference: ' + p.ref + '\n' +
    '  Student: ' + p.studentName + '\n' +
    '  Date of Birth: ' + p.dob + '\n' +
    '  Gender: ' + p.gender + '\n' +
    '  Level: ' + p.level + '\n' +
    '  Grade: ' + p.studentClass + '\n' +
    '  School: ' + p.school + '\n' +
    '  Region: ' + p.region + '\n' +
    '  Nominee Category: ' + p.category + '\n' +
    '  Parent/Guardian: ' + p.parentName + '\n' +
    '  Parent Phone: ' + p.parentPhone + '\n' +
    '  Parent Email: ' + p.parentEmail + '\n' +
    '  Photo: ' + (photoUrl || 'not saved') + '\n';

  var htmlBody =
    '<div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;">' +
    '<h2 style="color:#B8860B;">📋 New Registration</h2>' +
    '<table style="width:100%;border-collapse:collapse;font-size:14px;">' +
    '<tr><td style="padding:4px 0;color:#666;">Reference</td><td style="padding:4px 0;"><strong>' + p.ref + '</strong></td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Student</td><td style="padding:4px 0;">' + p.studentName + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Date of Birth</td><td style="padding:4px 0;">' + p.dob + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Gender</td><td style="padding:4px 0;">' + p.gender + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Level</td><td style="padding:4px 0;">' + p.level + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Grade</td><td style="padding:4px 0;">' + p.studentClass + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">School</td><td style="padding:4px 0;">' + p.school + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Region</td><td style="padding:4px 0;">' + p.region + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Nominee Category</td><td style="padding:4px 0;">' + p.category + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Parent/Guardian</td><td style="padding:4px 0;">' + p.parentName + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Parent Phone</td><td style="padding:4px 0;">' + p.parentPhone + '</td></tr>' +
    '<tr><td style="padding:4px 0;color:#666;">Parent Email</td><td style="padding:4px 0;">' + p.parentEmail + '</td></tr>' +
    '</table>' +
    (photoUrl && photoUrl.indexOf('ERROR') !== 0 ? '<p><img src="' + photoUrl + '" width="90" style="border-radius:50%;"></p>' : '') +
    '</div>';

  MailApp.sendEmail({
    to: ORGANIZER_EMAIL,
    subject: subject,
    body: body,
    htmlBody: htmlBody,
    name: 'CTVA Registration System'
  });
}

// Basic presence/format/length checks. Keeps garbage and oversized
// payloads out of the sheet even if the client-side checks are bypassed.
function validateRegistration(p) {
  var errors = [];
  var text = function(v) { return (typeof v === 'string') ? v.trim() : ''; };

  if (!text(p.studentName) || text(p.studentName).length > 60) errors.push('Invalid student name.');
  if (!text(p.school) || text(p.school).length > 80) errors.push('Invalid school name.');
  if (!text(p.studentClass) || text(p.studentClass).length > 30) errors.push('Invalid class.');
  if (!text(p.parentName) || text(p.parentName).length > 60) errors.push('Invalid parent/guardian name.');
  if (!text(p.level) || ['Primary', 'JHS', 'SHS'].indexOf(p.level) === -1) errors.push('Invalid school level.');
  if (!text(p.gender) || ['Male', 'Female'].indexOf(p.gender) === -1) errors.push('Invalid gender selection.');
  if (p.consent !== 'true') errors.push('Consent is required.');

  var email = text(p.parentEmail);
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('A valid parent/guardian email is required.');

  var phone = text(p.parentPhone).replace(/[\s\-]/g, '');
  if (!/^(\+?233|0)\d{9}$/.test(phone)) errors.push('Invalid parent/guardian phone number.');

  if (!p.photoData || p.photoData.indexOf('data:image/') !== 0) {
    errors.push('A valid student photo is required.');
  } else {
    // Rough size check on the base64 string itself (base64 is ~1.37x the
    // decoded byte size) before we bother decoding it.
    var approxBytes = p.photoData.length * 0.75;
    if (approxBytes > MAX_PHOTO_BYTES) errors.push('Photo is too large.');
  }

  return errors;
}

// Strips characters that have no business being in a name/school/phone
// field and could otherwise be used to inject spreadsheet formulas
// (e.g. a value starting with "=", "+", "-", "@").
function sanitize(v) {
  var s = (typeof v === 'string') ? v.trim() : '';
  if (/^[=+\-@]/.test(s)) s = "'" + s; // neutralize formula injection
  return s;
}

// Decodes the base64 JPEG data URL sent from the browser and saves it into
// a dedicated Drive folder, named by registration reference so it's easy
// to match back to a row in the sheet.
function savePhotoToDrive(dataUrl, ref, studentName) {
  var match = dataUrl.match(/^data:(image\/[a-zA-Z]+);base64,(.*)$/);
  if (!match) throw new Error('Malformed photo data');

  var mimeType = match[1];
  var base64Data = match[2];
  var bytes = Utilities.base64Decode(base64Data);

  if (bytes.length > MAX_PHOTO_BYTES) throw new Error('Photo exceeds size limit');

  var ext = mimeType.indexOf('png') > -1 ? 'png' : 'jpg';
  var fileName = (ref || 'STUDENT') + '_' + (studentName || '').replace(/[^a-zA-Z0-9]+/g, '_') + '.' + ext;

  var blob = Utilities.newBlob(bytes, mimeType, fileName);
  var folder = getOrCreatePhotoFolder();
  var file = folder.createFile(blob);

  // Anyone with the link can view — needed so the URL can be opened
  // directly from the sheet without requiring Drive access to the folder.
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return file.getUrl();
}

function getOrCreatePhotoFolder() {
  var folders = DriveApp.getFoldersByName(PHOTO_FOLDER_NAME);
  if (folders.hasNext()) return folders.next();
  return DriveApp.createFolder(PHOTO_FOLDER_NAME);
}

function getOrCreateSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow([
      'Reference', 'Student Name', 'Date of Birth', 'Gender', 'Level', 'School', 'Region', 'Grade',
      'Nominee Category', 'Parent/Guardian Name', 'Parent/Guardian Phone', 'Parent/Guardian Email',
      'Consent Given', 'Photo URL', 'Submitted (client)', 'Submitted (server)'
    ]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function jsonOut(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// ══════════════════════════════════════
//  MANUAL TEST HELPER
//  Select this function in the Apps Script editor's dropdown and click
//  Run to test the whole flow (sheet + Drive photo) without needing to
//  submit the real HTML form. Check the Execution log for the result.
//  Remember to set the "secret" field below to match SHARED_SECRET.
// ══════════════════════════════════════
function testRegisterStudent() {
  var fakeEvent = {
    postData: {
      contents: JSON.stringify({
        action: 'registerStudent',
        secret: SHARED_SECRET,
        website: '', // honeypot — must stay empty
        ref: 'CTVA-2026-TEST-' + Date.now(),
        studentName: 'Test Student',
        dob: '2011-05-14',
        gender: 'Female',
        level: 'SHS',
        school: 'Test School',
        region: 'Greater Accra',
        studentClass: 'SHS 1',
        category: 'Best Local News Anchor',
        parentName: 'Test Parent',
        parentPhone: '0240000000',
        parentEmail: 'YOUR_TEST_EMAIL_HERE@example.com',
        consent: 'true',
        photoData: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
        date: new Date().toISOString()
      })
    }
  };

  var result = doPost(fakeEvent);
  Logger.log(result.getContent());
}

// ══════════════════════════════════════
//  TEST: duplicate category at same school should be REJECTED.
//  Run testRegisterStudent() first (it uses school "Test School" +
//  category "Best Local News Anchor"), then run this — it uses the same
//  school and category with a different student, and should come back
//  with a status:error naming "Test Student" as already holding it.
// ══════════════════════════════════════
function testDuplicateCategoryRejected() {
  var fakeEvent = {
    postData: {
      contents: JSON.stringify({
        action: 'registerStudent',
        secret: SHARED_SECRET,
        website: '',
        ref: 'CTVA-2026-TEST-DUP-' + Date.now(),
        studentName: 'Second Test Student',
        dob: '2010-02-20',
        gender: 'Male',
        level: 'SHS',
        school: 'Test School', // same school as testRegisterStudent
        region: 'Greater Accra',
        studentClass: 'SHS 2',
        category: 'Best Local News Anchor', // same category — should be rejected
        parentName: 'Another Test Parent',
        parentPhone: '0240000001',
        parentEmail: 'YOUR_TEST_EMAIL_HERE@example.com',
        consent: 'true',
        photoData: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
        date: new Date().toISOString()
      })
    }
  };

  var result = doPost(fakeEvent);
  Logger.log(result.getContent());
}
